# Inventory Management System — 2,000+ Synthetic CSV Dataset

Interconnected synthetic sample data for a MySQL inventory-management project. All people, companies, contact details, addresses and transactions are fictional. Email addresses use the reserved `.example` domain.

## Dataset size
**Total: 5,795 data rows across 13 CSV files.**

| File | Rows |
|---|---:|
| `stock_movements.csv` | 1,200 |
| `customers.csv` | 400 |
| `purchase_orders.csv` | 120 |
| `categories.csv` | 8 |
| `warehouses.csv` | 6 |
| `employees.csv` | 25 |
| `warehouse_inventory.csv` | 900 |
| `sales_order_items.csv` | 1,500 |
| `suppliers.csv` | 20 |
| `payments.csv` | 500 |
| `purchase_order_items.csv` | 466 |
| `sales_orders.csv` | 500 |
| `products.csv` | 150 |

## Recommended import order
1. `categories.csv`
2. `suppliers.csv`
3. `warehouses.csv`
4. `customers.csv`
5. `employees.csv`
6. `products.csv`
7. `warehouse_inventory.csv`
8. `purchase_orders.csv`
9. `purchase_order_items.csv`
10. `sales_orders.csv`
11. `sales_order_items.csv`
12. `payments.csv`
13. `stock_movements.csv`

Create the target MySQL schema before importing. Import parent tables before dependent tables to satisfy foreign-key constraints. CSV headers are intended to match the project schema.

## Data integrity and caveats
- Product category and supplier IDs reference existing records.
- Warehouse inventory has one unique row for each product/warehouse pair.
- Purchase order items and sales order items reference valid orders and products.
- Payment records reference valid sales orders and contain illustrative order totals.
- `stock_movements.reference_id` is polymorphic: it refers to a purchase order for `Stock In`, a sales order for `Stock Out`, and is blank for `Adjustment`. It is not a conventional foreign key in the schema.
- Inventory balances and movement history are generated as separate illustrative datasets; the movement ledger is not guaranteed to reconcile exactly to the current balance. Reconciliation can be a useful extension task.
- Files are UTF-8 CSVs with header rows.
